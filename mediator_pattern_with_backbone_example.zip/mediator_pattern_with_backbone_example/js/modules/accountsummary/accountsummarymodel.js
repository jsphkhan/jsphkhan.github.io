define(function() {
	var AccountSummaryModel = Backbone.Model.extend({
		initialize: function() {
			console.log('Account Summary Model initialized');
		}
	});
	return AccountSummaryModel;
});